import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css']
})
export class PostsComponent implements OnInit {
  private URL = "https://jsonplaceholder.typicode.com/posts";
  private commentURL = "https://jsonplaceholder.typicode.com/comments?postId=";
  postData:any;
  postCommentData:any;
  
  constructor(private http:HttpClient) { }

  
  ngOnInit(): void {
  }

  getPosts():void{
    this.http.get(this.URL)
    .subscribe(res=>{
       this.postData=res;
    })
  }

  getComments(id:number):void{
    this.http.get(this.commentURL + id)
    .subscribe(res => {
      console.log(res);
      this.postCommentData=res;
    });
  }

  
}
