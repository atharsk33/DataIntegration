import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-albums',
  templateUrl: './albums.component.html',
  styleUrls: ['./albums.component.css']
})
export class AlbumsComponent implements OnInit {
  private URL = "https://jsonplaceholder.typicode.com/albums";
  albumDATA:any;
  constructor(private http:HttpClient) { }

  ngOnInit(): void {
    this.http.get(this.URL)
    .subscribe(res => {
      this.albumDATA=res;
    });
  }

}
