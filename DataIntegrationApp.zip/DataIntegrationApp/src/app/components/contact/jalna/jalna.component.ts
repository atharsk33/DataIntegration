import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jalna',
  templateUrl: './jalna.component.html',
  styleUrls: ['./jalna.component.css']
})
export class JalnaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
