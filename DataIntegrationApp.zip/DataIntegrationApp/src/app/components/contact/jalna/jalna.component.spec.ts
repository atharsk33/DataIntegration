import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JalnaComponent } from './jalna.component';

describe('JalnaComponent', () => {
  let component: JalnaComponent;
  let fixture: ComponentFixture<JalnaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ JalnaComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(JalnaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
