import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aurangabad',
  templateUrl: './aurangabad.component.html',
  styleUrls: ['./aurangabad.component.css']
})
export class AurangabadComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
