import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AurangabadComponent } from './aurangabad.component';

describe('AurangabadComponent', () => {
  let component: AurangabadComponent;
  let fixture: ComponentFixture<AurangabadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AurangabadComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AurangabadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
