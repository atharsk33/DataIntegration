import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-photos',
  templateUrl: './photos.component.html',
  styleUrls: ['./photos.component.css']
})
export class PhotosComponent implements OnInit {
  private URL = "https://jsonplaceholder.typicode.com/photos";
  photoData:any;
  public showSpinner:boolean = true;

  constructor(private http:HttpClient) { }

  ngOnInit(): void {
    this.http.get(this.URL)
    .subscribe(res => {
       if (res) {
        this.hideloader();
    }
      this.photoData = res;
    });
  }

  
// Function is defined
hideloader(): void {
  // Setting display of spinner
  // element to none
  this.showSpinner = false;
}


}
