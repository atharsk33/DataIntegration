import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular World';
  courses:any = [];
  imgUrl="https://picsum.photos/200/300";
  empData = [{Id:1,Name:"A",Age:23,City:"Z"},
             {Id:2,Name:"B",Age:33,City:"Y"},
             {Id:3,Name:"C",Age:43,City:"X"},
             {Id:4,Name:"D",Age:53,City:"W"},
             {Id:5,Name:"E",Age:63,City:"V"}];
  showCourses(){
    //alert("You clicked me. Why?");
    this.courses = ["PHP", "JAVA", "C#", "PYTHON"];
    this.imgUrl = "https://picsum.photos/200/300?random=1";
  }
}
